# @coinsenda/sdk

Node.js SDK for [Coinsenda](https://coinsenda.com) — a crypto exchange platform.

Authentication uses **RSA public key signatures**. Before calling the SDK you must generate a key pair locally and register the **public key** in your Coinsenda account profile settings. The **private key** never leaves your environment.

## Installation

```bash
npm install @coinsenda/sdk jsonwebtoken node-rsa
```

## Prerequisites

### 1. Generate an RSA key pair

Create a 2048-bit RSA key pair on your machine. Store the **private key** securely — you will use it on every login.

```javascript
const NodeRSA = require('node-rsa');

let key = new NodeRSA({ b: 2048 });
let public_key = key.exportKey('pkcs8-public-pem');
let private_key = key.exportKey('pkcs8-private-pem');

// Save private_key in a secrets manager or env variable — never commit it
```

You can also generate the pair with OpenSSL:

```bash
openssl genrsa -out private.pem 2048
openssl rsa -in private.pem -pubout -out public.pem
```

### 2. Register the public key in your Coinsenda account

Sign in to your Coinsenda account and open **Profile Settings → API Public Key**.

Paste the **public key** (PEM format) and save. Coinsenda stores it in your profile and uses it to verify future signature-based logins.

This step is required **once per key pair**. If you rotate keys, register the new public key before authenticating with the new private key.

## Authentication

Every session needs:

| Requirement | Description |
|-------------|-------------|
| Registered public key | Saved in your Coinsenda profile settings |
| Private key | Held locally; used to sign the login token |

### Full example

```javascript
const NodeRSA = require('node-rsa');
const jwt = require('jsonwebtoken');
const { CoinsendaClient, isHttpSuccess } = require('@coinsenda/sdk');

async function authenticate(email, private_key_pem) {
  // 1. Create client
  let client = new CoinsendaClient({ domain: 'coinsenda.com' });

  // 2. Sign a short-lived token with your private key
  let rsa_key = new NodeRSA(private_key_pem, 'pkcs8-private-pem');
  let signed_token = jwt.sign(
    { email: email, iat: Math.floor(Date.now() / 1000) },
    rsa_key.exportKey('private'),
    { algorithm: 'RS256', expiresIn: '5m' }
  );

  // 3. Authenticate via POST /auth/pubkey
  let auth_result = await client.auth.passport.authPubkey({
    data: { signed_token }
  });

  if (!isHttpSuccess(auth_result.status)) {
    throw new Error(`Authentication failed: ${auth_result.status}`);
  }

  let response_data = auth_result.data?.data || auth_result.data;
  client.setJwt(response_data.jwt);
  client.setRefreshToken(response_data.refresh_token);

  return client;
}

// Usage
let client = await authenticate('user@example.com', process.env.COINSENDA_PRIVATE_KEY);

let profile = await client.transaction.user.__get__profile();
console.log(profile.data);
```

### Identifier in the signed token

The payload you sign must identify your Coinsenda account:

| Field | When to use |
|-------|-------------|
| `email` | Default — matches the email on your Coinsenda account |
| `userId` | When you know your Coinsenda user ID |
| `phone_number` | Phone-based accounts |

Always include `iat` (issued-at timestamp). The token expires after 5 minutes — generate a new one for each login attempt.

## Environment

```javascript
// Production
new CoinsendaClient({ domain: 'coinsenda.com' });

// Staging
new CoinsendaClient({ domain: 'bitsenda.com' });

// Local development (requires config/environments.local.js)
new CoinsendaClient({ environment: 'local' });
```

Copy `config/environments.local.example.js` to `config/environments.local.js` and adjust ports if needed.

## Calling endpoints

After authentication, all requests include `Authorization: Bearer <jwt>` automatically.

Methods follow `client.{service}.{model}.{method}(data)`:

```javascript
await client.account.user.__get__accounts();
await client.deposit.user.__get__deposits();
await client.withdraw.withdraw.addNewWithdrawPublic({ ... });
```

Responses are raw server objects: `{ status, data, headers }`. Use `isHttpSuccess(result.status)` to check for 2xx.

## License

Apache-2.0
